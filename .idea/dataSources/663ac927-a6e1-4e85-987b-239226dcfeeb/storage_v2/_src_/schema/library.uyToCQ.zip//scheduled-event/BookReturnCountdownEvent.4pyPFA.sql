create definer = root@localhost event BookReturnCountdownEvent on schedule
    every '1' DAY
        starts '2021-06-09 00:00:00'
    on completion preserve
    enable
    do
    update borrowingRecords
       set deadline = deadline - 1
       where returned = false;

